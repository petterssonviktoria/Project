<?php include("header.php"); ?>
<?php include("config.php"); ?>


<!doctype html>
<html>
	<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/style.css">
	<title>Program</title>
	</head>
	<body>
		<div id="trainers">
			
				<div class="trainer">

                    <img id="bla" src="img/anders.jpeg">
                    <div class="text">
					<?php

				    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                  

                    $query = " SELECT Trainer.name FROM Trainer WHERE Trainer.Nr='1'";
                   
                  
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Trainer);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td><h1>$Trainer</h1></td> "; 
                            echo "</tr>";
                            
                        }
                        echo "</table>";

                        

                        $query = " SELECT Trainer.phone, Trainer.gym FROM Trainer WHERE Trainer.Nr='1'";

                        $stmt = $db->prepare($query);
                        $stmt->bind_result($phone, $gym);
                        $stmt->execute();
                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo "<td>Phonenr:</td><td> $phone </td> <td>Gym:</td><td>$gym</td>";
                            echo "</tr>";
                        }
                        echo "</table>";


                        $query = "SELECT  Program FROM Programme WHERE Trainer='1'";

                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Program);
                        $stmt->execute();
                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td>$Program</td> "; 
                            echo "</tr>";
                            
                        }
                        echo "</table>";
                       	    
            
                    ?>   
                    </div>
               
					
				</div>
				
				<div class="trainer">
                    <img src="img/26fitness.jpg">
                    <div class="text">
					<?php

				    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                  

                  $query = " SELECT Trainer.name FROM Trainer WHERE Trainer.Nr='2'";
                   
                  
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Trainer);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td><h1>$Trainer</h1></td> "; 
                            echo "</tr>";
                            
                        }
                        echo "</table>";

                        $query = " SELECT Trainer.phone, Trainer.gym FROM Trainer WHERE Trainer.Nr='2'";

                        $stmt = $db->prepare($query);
                        $stmt->bind_result($phone, $gym);
                        $stmt->execute();
                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo "<td>Phonenr:</td><td> $phone </td> <td>Gym:</td><td>$gym</td>";
                            echo "</tr>";
                        }
                        echo "</table>";

                        $query = "SELECT  Program FROM Programme WHERE Trainer='2'";

                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Program);
                        $stmt->execute();
                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td>$Program</td> "; 
                            echo "</tr>";
                            
                        }
                        echo "</table>";
            
                    ?>   
                    </div>	
				</div>
				
				<div class="trainer">
					<img src="img/person.jpg">
					<div class="text">

                        <?php

                    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                  

                    $query = " SELECT Trainer.name FROM Trainer WHERE Trainer.Nr='3'";
                   
                  
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Trainer);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td><h1>$Trainer</h1></td> "; 
                            echo "</tr>";
                            
                        }
                        echo "</table>";

                        $query = " SELECT Trainer.phone, Trainer.gym FROM Trainer WHERE Trainer.Nr='3'";

                        $stmt = $db->prepare($query);
                        $stmt->bind_result($phone, $gym);
                        $stmt->execute();
                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo "<td>Phonenr:</td><td> $phone </td> <td>Gym:</td><td>$gym</td>";
                            echo "</tr>";
                        }
                        echo "</table>";

                        $query = "SELECT  Program FROM Programme WHERE Trainer='3'";

                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Program);
                        $stmt->execute();
                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                      //  echo '<tr><b> <td>Program</td> <td>Trainer</td> <td> Phonenumber </td> <td>Gym</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td>$Program</td> "; 
                            echo "</tr>";
                            
                        }
                        echo "</table>";
            
                    ?>
						
					</div>
				</div>
		</div>
		<?php include("footer.php"); ?>
	</body>
</html>