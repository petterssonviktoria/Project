<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<?php include("header.php"); ?>
		</header>
		<main>
			<div id="ring">
				<img src="img/ring.jpg">
			</div>
			<div class="bodytext">
				<form id="contact">
					<?php
						$Name = addslashes($Name); 
					   	$Email = addslashes($Email);
					   	$subject = addslashes($subject);

					   	$Name = htmlentities($Name);
					   	$Email = htmlentities($Emial);
					   	$subject = htmlentities($subject);
					?>
					<p>
						Name
					</p>
					<input type="text" name="Name" placeholder="Eva Karlsson">
					<p>
						Email
					</p>
					<input type="text" name="Email" placeholder="evakarlsson@exampie.se">
					<p>
						Write some words
					</p>
					<textarea id="subject" name="subject" placeholder="Write something.." rows="10"></textarea>
					<input type="submit" value="Send">
				</form>

			</div>
		</main>
		<footer>
				<?php include("footer.php"); ?>
		</footer>
	</body>

</html>