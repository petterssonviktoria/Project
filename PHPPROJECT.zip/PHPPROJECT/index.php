<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<?php include("header.php"); ?>
		</header>
		<main>
			<div class="bodytext">
				<img src="img/run.jpg">
			</div>
		</main>
		<footer>
				<?php include("footer.php"); ?>
		</footer>
	</body>

</html>