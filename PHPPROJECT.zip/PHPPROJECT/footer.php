<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<footer>
			Copyright 2017, All rights reserved
		</footer>
	</body>

</html>	