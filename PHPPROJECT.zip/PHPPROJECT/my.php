<?php include("config.php"); ?>
<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<?php include("header.php"); ?>
		</header>
		<main>
			<div id="hej">
				<img src="img/hej.jpg">
			</div>
			<!-- <form action="my.php" method="POST">
				<tr>
				                <td>Title:</td>
				                <td><INPUT type="text" name="searchprogramme"></td>
				            </tr>
				            <tr>
				                <td>Author:</td>
				                <td><INPUT type="text" name="searchtrainer"></td>
				            </tr>
				<input type="submit" value="Search">
			</form> -->
			<?php
	
				$searchprogramme = "";
                $searchtrainer = "";

				if (isset($_POST) && !empty($_POST)) {
                    # Get data from form
                    $searchprogramme = trim($_POST['searchprogramme']);
                    $searchtrainer = trim($_POST['searchtrainer']);
                    }

                    $searchprogramme = addslashes($searchprogramme);
                    $searchtrainer = addslashes($searchtrainer);

				# Open the database
				@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

				if ($db->connect_error) {
				    echo "could not connect: " . $db->connect_error;
				    printf("<br><a href=index.php>Return to home page </a>");
				    exit();
				}

				# Build the query. Users are allowed to search on title, author, or both
				$query = " SELECT Programme.Nr, Programme.Program, Trainer.name, Difficulty.level, Category.Name, Programme.save, Programme.done FROM Programme
                JOIN Trainer ON Programme.Trainer = Trainer.Nr
                JOIN Difficulty ON Programme.Difficulty = Difficulty.ID
                JOIN Category ON Programme.Category = Category.ID";
				if ($searchprogramme && !$searchtrainer) { // Title search only
                    $query = $query . " where Program like '%" . $searchprogramme . "%'";
                }
                if (!$searchprogramme && $searchtrainer) { // Author search only
                   	$query = $query . " where Trainer like '%" . $searchtrainer . "%'";
                }
                if ($searchprogramme && $searchtrainer) { // Title and Author search
                    $query = $query . " where Program like '%" . $searchprogramme . "%' and Trainer like '%" . $searchtrainer . "%'"; // unfinished
                        
                }
                

			
				$stmt = $db->prepare($query);
                $stmt->bind_result($Nr, $Program, $Trainer, $Difficulty, $Category, $save, $done);
                $stmt->execute();

                echo '<table bgcolor="" cellpadding="6" width="100%">';

                echo '<tr><b> <td>Nr</td> <td>Program</td> <td>Trainer</td> <td> Difficulty </td> <td>Category</td> <td>Saved?</td> <td>Done?</td> <td>Done</td> </b> </tr>';
                while ($stmt->fetch()) {
                    if($save==1){
                    	$save="YES";
                    }else {
                    	$save="NO";
                    }
                    if($done==1){
                    	$done="YES";
                    }else{
                    	$done="NO";
                    }
                    	
                         

                echo "<tr>";
                echo "<td>$Nr</td> <td>$Program</td>"; 
                echo '<td><a href="trainers.php?Nr=' . urlencode($firstname) . '"> '.$Trainer.' </a></td>';
                echo '<td><a href="programs.php?ID=' . urlencode($level) . '"> '.$Difficulty.' </a></td>';
                echo '<td><a href="programs.php?ID=' . urlencode($Name) . '"> '.$Category.' </a></td>';
                echo "<td>$save</td><td>$done</td>";
                echo '<td><a href="done.php?Nr=' . urlencode($Nr) . '"> <input type="button" value="Done"> </a></td>';
                echo "</tr>";
                }
                echo "</table>";

			?>
		</main>
		<footer>
				<?php include("footer.php"); ?>
		</footer>
	</body>

</html>