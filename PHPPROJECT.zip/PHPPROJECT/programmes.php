<?php include("header.php"); ?>
<?php include("config.php"); ?>

<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="FAQ- Particle Lovers" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<main>
			<form id="search" action="programmes.php" method="POST">
				<p>
					Programme
				</p>
				<input type="text" name="searchprogramme">
				<p>
					Trainer
				</p>
				<input type="text" name="searchtrainer" >
				<input type="submit" value="Search">
			</form>
			 <?php

                    $searchprogramme = "";
                    $searchtrainer = "";

                    if (isset($_POST) && !empty($_POST)) {
                    # Get data from form
                        $searchprogramme = trim($_POST['searchprogramme']);
                        $searchtrainer = trim($_POST['searchtrainer']);
                    }

                    $searchprogramme = addslashes($searchprogramme);
                    $searchtrainer = addslashes($searchtrainer);


                    $searchprogramme = htmlentities($searchprogramme);
                    $searchtrainer = htmlentities($searchtrainer);
                   

                    # Open the database
                    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                    # Build the query. Users are allowed to search on title, author, or both
                    $query = " SELECT Programme.Nr, Programme.Program, Trainer.name, Difficulty.level, Category.Name, Programme.save FROM Programme
                    JOIN Trainer ON Programme.Trainer = Trainer.Nr
                    JOIN Difficulty ON Programme.Difficulty = Difficulty.ID
                    JOIN Category ON Programme.Category = Category.ID";

                    if ($searchprogramme && !$searchtrainer) { // Title search only
                        $query = $query . " where Program like '%" . $searchprogramme . "%'";
                    }
                    if (!$searchprogramme && $searchtrainer) { // Author search only
                        $query = $query . " where Trainer like '%" . $searchtrainer . "%'";
                    }
                    if ($searchprogramme && $searchtrainer) { // Title and Author search
                        $query = $query . " where Program like '%" . $searchprogramme . "%' and Trainer like '%" . $searchtrainer . "%'"; // unfinished
                        
                    }
                    // echo "Running the $query <br/>:";

                   
                    # Here's the query using bound result parameters
                        // echo "we are now using bound result parameters <br/>";
                  
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Nr, $Program, $Trainer, $Difficulty, $Category, $save);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="6" width="100%">';

                        echo '<tr><b> <td>Nr</td> <td>Program</td> <td>Trainer</td> <td> Difficulty </td> <td>Category</td> <td>Saved?</td> <td>Add</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            if($save==0)
                                $save="NO";
                            else $save="YES";

                            echo "<tr>";
                            echo "<td>$Nr</td> <td>$Program</td>"; 
                            echo '<td><a href="trainers.php?Nr=' . urlencode($Nr) . '"> '.$Trainer.'  </a></td>';
                            echo '<td><a href="programs.php?ID=' . urlencode($ID) . '"> '.$Difficulty.' </a></td>';
                            echo '<td><a href="programs.php?ID=' . urlencode($ID) . '"> '.$Category.' </a></td>';
                            echo "<td>$save</td>";
                            echo '<td><a href="add.php?Nr=' . urlencode($Nr) . '"> <input type="button" value="Add"> </a></td>';
                            echo "</tr>";
                        }
                        echo "</table>";
            ?>
		</main>
		<footer>
				<?php include("footer.php"); ?>
		</footer>
	</body>

</html>