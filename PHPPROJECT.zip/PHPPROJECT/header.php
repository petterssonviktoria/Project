<?php include("config.php"); ?>


<!doctype html> 
	<?php
	$cookie_name = "user";
	$cookie_value = "John Doe";
	$cookieOut = time()+86400;
	setcookie($cookie_name, $cookie_value, $cookieOut);
	?>
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />

	</head>
	<body>

	<?php
		if(!isset($_COOKIE[$cookie_name])) {
		    echo "Cookie named '" . $cookie_name . "' is set!";
		} else {
		    echo "Cookie '" . $cookie_name . "' is not set!<br>";
		    echo "Value is: " . $_COOKIE[$cookie_name];
		}
	?>
		<header>
			<div>
				<h1> LOSE IT!</h1>
			</div>
			<div class="headnav">

				<nav>
					<ul>
						<li>
							<a class="<?php echo ($current_page =='index.php'||$current_page=="") ? 'active' : NULL?>" 
               				 href="index.php">Home</a>
						</li>
						<li>								
							
							<a class="<?php echo $current_page =='programmes.php' ? 'active' : NULL?>" 
               				 href="programmes.php">Search</a>
						</li>
						<li>
							<a class="<?php echo $current_page =='my.php' ? 'active' : NULL?>" 
           				     href="my.php">My programmes</a>
							
						</li>
						<li>
							<a class="<?php echo $current_page =='finnished.php' ? 'active' : NULL?>" 
               				 href="finnished.php">Finished programmes</a>
							
						</li>
						<li>
							<a class="<?php echo $current_page =='contact.php' ? 'active' : NULL?>" 
             			   href="contact.php">Contact</a>
						</li>
						<li>
							<a class="<?php echo $current_page =='gallery.php' ? 'active' : NULL?>" 
             			   href="galley.php">Gallery</a>
						</li>
						<li>
							<a class="<?php echo $current_page =='programs.php' ? 'active' : NULL?>" 
             			   href="programs.php">Programmes</a>
						</li>
						<li>
							<a class="<?php echo $current_page =='trainers.php' ? 'active' : NULL?>" 
             			   href="trainers.php">Trainers</a>
						</li>
					</ul>
				</nav>

			</div>
			<div>
				

				
			</div>
		</header>

	</body>

</html>	