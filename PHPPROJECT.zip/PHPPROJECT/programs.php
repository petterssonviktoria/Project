<?php include("header.php"); ?>

<?php include("config.php"); ?>

<!doctype html>
<html>
	<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/style.css">
	<title>Program</title>
	</head>
	<body>

	

		<div id="programs">
			
				<img src="img/bodypump.jpg">


                 <?php

				    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                  

                    $query = " SELECT Programme.Program, Programme.description FROM Programme WHERE Programme.Program='Body pump' ";
                   
                  
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Program, $description);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="20" width="100%">';

                       // echo '<tr><b> <td>Program</td> <td> Difficulty </td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                             echo "<tr>";
                            echo " <td><h1>$Program</h1></td>";
                            echo "</tr>";
                            echo "<tr>";
                          	echo "<td>$description</td>"; 
                            echo "</tr>";
                        }
                        echo "</table>";
            
                 ?>             
                       
                     

				
				<img src="img/yoga.jpg">

				<?php

				    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                  

                    $query = " SELECT Programme.Program, Programme.description FROM Programme WHERE Programme.Program='Yoga' ";
                   
                  
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Program, $description);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="20" width="100%">';

                       // echo '<tr><b> <td>Program</td> <td> Difficulty </td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td><h1>$Program</h1></td>";
                            echo "</tr>";
                            echo "<tr>";
                          	echo "<td>$description</td>"; 
                            echo "</tr>";
                        }
                        echo "</table>";
            
                 ?>     
				
					
				
				<img src="img/crossfit.jpg">

				<?php

				    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                  

                    $query = " SELECT Programme.Program, Programme.description FROM Programme WHERE Programme.Program='Crossfit' ";
                   
                  
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Program, $description);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="20" width="100%">';

                       // echo '<tr><b> <td>Program</td> <td> Difficulty </td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td><h1>$Program</h1></td>";
                            echo "</tr>";
                            echo "<tr>";
                          	echo "<td>$description</td>"; 
                            echo "</tr>";
                        }
                        echo "</table>";
            
                 ?>     
				
					
			
				<img src="img/balance.jpg">

				<?php

				    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                  

                    $query = " SELECT Programme.Program, Programme.description FROM Programme WHERE Programme.Program='Bodybalance' ";
                   
                  
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Program, $description);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="20" width="100%">';

                       // echo '<tr><b> <td>Program</td> <td> Difficulty </td> </b> </tr>';
                        while ($stmt->fetch()) {
                            
                            echo "<tr>";
                            echo " <td><h1>$Program</h1></td>";
                            echo "</tr>";
                            echo "<tr>";
                          	echo "<td>$description</td>"; 
                            echo "</tr>";
                        }
                        echo "</table>";
            
                 ?>     
				
				

		</div>
		<?php include("footer.php"); ?>
	</body>
</html>




