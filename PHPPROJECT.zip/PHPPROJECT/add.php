<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include ("config.php");
?>

<!doctype html> 
<html>
    <head> 
        <title>My title</title>
        <meta name="description" content="Training" />
        <meta charset="utf-8"/>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <header>
            <?php include("header.php"); ?>
        </header>
        <main>
            <div id="add">
                <?php
                     $programmeNr = trim($_GET['Nr']);
                    echo '<INPUT type="hidden" name="Nr" value=' . $programmeNr . '>';

                    $programmeNr = trim($_GET['Nr']);      // From the hidden field
                    $programmeNr = addslashes($programmeNr);

                    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                        if ($db->connect_error) {
                            echo "could not connect: " . $db->connect_error;
                            printf("<br><a href=index.php>Return to home page </a>");
                            exit();
                        }
                        
                       echo "You are reserving book with the ID:"           .$programmeNr;

                        // Prepare an update statement and execute it
                        $stmt = $db->prepare("UPDATE Programme SET save=1 WHERE Nr = ?");
                        $stmt->bind_param('i', $programmeNr);
                        $stmt->execute();
                        printf("<br>Book Reserved!");
                        printf("<br><a href=programmes.php>Search for more programmes </a>");
                        printf("<br><a href=my.php>Return to my programmes </a>");
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit;
                 ?>
            </div>
        </main>
        <footer>
                <?php include("footer.php"); ?>
        </footer>
    </body>

</html>