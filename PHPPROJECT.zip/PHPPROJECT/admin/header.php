<?php
//PUT THIS HEADER ON TOP OF EACH UNIQUE PAGE
session_start();
if (!isset($_SESSION['username'])) {
    header("admin.php");
}

?>
<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<div class="headnav">
				<nav>
					<?php include 'config.php'; ?>
					<ul>
						<li>
							<a class="<?php echo ($current_page =='admin.php'||$current_page=="") ? 'active' : NULL?>" 
               				 href="admin.php">Home</a>
						</li>
						<li>
							<a class="<?php echo $current_page =='addProgramme.php' ? 'active' : NULL?>" 
               				 href="addProgramme.php">Add</a>
						</li>
						<li>								
							
							<a class="<?php echo $current_page =='delete.php' ? 'active' : NULL?>" 
               				 href="delete.php">Delete</a>
						</li>
						<li>
							<a class="<?php echo $current_page =='upload.php' ? 'active' : NULL?>" 
           				     href="upload.php">Upload</a>
							
						</li>
						
						
					</ul>
				</nav>
			</div>
			<div>
				
			</div>
		</header>
	</body>

</html>	