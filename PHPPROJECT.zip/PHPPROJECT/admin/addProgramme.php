<?php

session_start();
if (!isset($_SESSION['username'])) {
    header("admin.php");
}


include("config.php");
$title = "Add new programme";
include("header.php");




if (isset($_POST['newprogramme'])) {
    
    $newprogramme = trim($_POST['newprogramme']);
    $newNr = trim($_POST['newNr']);
    $newTrainer = trim($_POST['newTrainer']);
    $newDifficulty = trim($_POST['newDifficulty']);
    $newCategory = trim($_POST['newCategory']);
    $newDescription = trim($_POST['newDescription']);
    

    if (!$newprogramme || !$newNr) {
        printf("You must specify both a Nr and a programme");
        printf("<br><a href=addProgramme.php>Return to add page </a>");
        exit();
    }

    $newprogramme = addslashes($newprogramme);
    $newNr = addslashes($newNr);
    $newDescription = addslashes($newDescription);
    
    

    # Open the database 
@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

    if ($db->connect_error) {
        echo "could not connect: " . $db->connect_error;
        printf("<br><a href=admin.php>Return to home page </a>");
        exit();
    }

    // Prepare an insert statement and execute it
    $stmt = $db->prepare("INSERT INTO Programme values (?, ?, ?, ?, ?, ?, 0, 0)");
    $stmt->bind_param('isiiis', $newNr, $newprogramme, $newTrainer, $newDifficulty, $newCategory, $newDescription);
    $stmt->execute();


    
    printf("<br>Programme Added!");
    echo ("INSERT INTO Programme values ($newNr, $newprogramme, $newTrainer, $newDifficulty, $newCategory, $newDescription, 0, 0)");
    printf("<br><a href=admin.php>Return to home page </a>");
    exit;
}


?>
<html>
<h3>Add a new Programme</h3>
<hr>
You must enter both a nr and a title and other stuff you have in the database....
</hr>



<form action="addProgramme.php" method="POST">
    <table bgcolor="" cellpadding="6" width="100%">
        <tbody>
            <tr>
                <td>Nr:</td>
                <td><INPUT type="text" name="newNr"></td>
            </tr>
            <tr>
                <td>Programme:</td>
                <td><INPUT type="text" name="newprogramme"></td>

            </tr>
            <tr>
                <td>Trainer:</td>
               
                 <td>
                    <select name="newTrainer"r>
                        
                            <?php
                            @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);
                            $result = $db->query("SELECT DISTINCT * FROM Trainer");
                                // output data of each row
                                foreach ($result as $index => $Trainer) {                       
                                    echo "<option value=" . $Trainer["Nr"] . ">" . $Trainer["name"] . "</option>";
                                }
                            $db->close();
                            ?>
                       
                    </select>
                </td>
            </tr>
            <tr>
                <td>Difficulty:</td>
                <td>
                    
                         <select name="newDifficulty">
                            <?php
                            @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);
                            $result = $db->query("SELECT DISTINCT * FROM Difficulty");
                                // output data of each row
                                foreach ($result as $index => $Difficulty) {                       
                                    echo "<option value=" . $Difficulty["ID"] . ">" . $Difficulty["description"] . "</option>";
                                }
                            $db->close();
                            ?>
                        </select>     
                </td>
            </tr>
            <tr>
                <td>Category:</td>
                <td>
                    <select name="newCategory">
                            <?php
                            @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);
                            $result = $db->query("SELECT DISTINCT * FROM Category");
                                // output data of each row
                                foreach ($result as $index => $Category) {                       
                                    echo "<option value=" . $Category["ID"] . ">" . $Category["description"] . "</option>";
                                }
                            $db->close();
                            ?>
                        </select>
                </td>
            </tr>
             <tr>
                <td>Description:</td>
                <td><INPUT type="text" name="newDescription"></td>

            </tr>    
            <tr>
                <td></td>
                <td><INPUT type="submit" name="submit" value="Add Programme"></td>
            </tr>
           
        </body>
    </table>
</form>
<?php include("footer.php"); ?> 
</html>