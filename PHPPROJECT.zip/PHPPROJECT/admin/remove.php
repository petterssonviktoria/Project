<?php
include("config.php");
$title = "Delete programme";
include("header.php");
?>

<?php
if (isset($_GET['submit'])) {
    // We know the borrower so go ahead and check the book out
    # Get data from form
    $id = trim($_GET['Nr']);      // From the hidden field
    $id = addslashes($id);

    # Open the database using the "librarian" account
    @ $db = new mysqli('localhost', 'root', 'root', 'Traning');

    if ($db->connect_error) {
        echo "could not connect: " . $db->connect_error;
        printf("<br><a href=admin.php>Return to home page </a>");
        exit();
    }

    // Prepare an update statement and execute it
    
        $stmt = $db->prepare("delete from Programme where Nr = ?");
        $stmt->bind_param('i', $id);
        $response = $stmt->execute();
        printf("<br>Programme deleted!");
        printf("<br><a href=delete.php>Go to delete page </a>");
    
    
    exit;
}

// We don't have a borrower id yet so present a form to get one,
// then post back using a hidden field to pass through the bookid
// which came from the hand-crafted URL query string on the book
// search page
?>

<h3>Delete programme</h3>
<hr>
<form action="remove.php" method="GET">
    Are you sure you want to delete book?
    <?php
    $id = trim($_GET['Nr']);
    echo '<INPUT type="hidden" name="Nr" value=' . $id . '>';
    ?>
    <INPUT type="submit" name="submit" value="Continue">
</form>
<?php include("footer.php"); ?>