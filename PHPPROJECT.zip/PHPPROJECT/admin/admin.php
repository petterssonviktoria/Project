<?php

session_start();
if (!isset($_SESSION['username'])) {
    header("admin.php");
}

?>
<!doctype html> 

			
				<?php 
					include("config.php"); 

				?>
				
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="book" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<?php include("header.php"); ?>

		</header>
		<main>
			<div class="bodytext">
				<h1>
					WELCOME!
				</h1>
				
			</div>


				<?php if(isset($_POST) && !empty($_POST)) : ?>

				<?php 
					$myusername =  stripslashes($_POST['username']);
					$mypassword =  stripslashes($_POST['userpass']);
					
					@ $db = new mysqli('localhost', 'root', 'root', 'Book club');

					if ($db->connect_error) {
						echo "could not connect: " . $db->connect_error;
						exit();
					}

					echo "SELECT username, password FROM User WHERE username =".$myusername;


					$stmt = $db->prepare("SELECT username, password FROM librarians WHERE username = ?");
					$stmt->bind_param('s', $myusername);
					$stmt->bind_result($username, $password);
					$stmt->execute();

					
					
				    

				    echo $username;
				    echo $password;

				    while ($stmt->fetch()) {
				        if (sha1($mypassword) == $password)
						{
							$_SESSION['username'] = $myusername;
							echo "funkar";
							header("location:addbook.php");
							exit();
						}
				    }

				?>

				<?php endif;?>


			<form method="POST">
       			 <p>Username</p>
            	<input type="text" name="username">
            	<p>Password</p>
           		<input type="password" name="userpass">
            	<input type="submit" value="Sign In">
    		</form>
    		<!-- <img src="foto/uggla.jpg"> -->
		</main>
		<footer>
				<?php include("../footer.php"); ?>
		</footer>
	</body>

</html>



