<?php
include("config.php");
$title = "Delete book";

session_start();
if (!isset($_SESSION['username'])) {
    header("admin.php");
}



?>

<!doctype html> 
<html>
    <head> 
        <title>My title</title>
        <meta name="description" content="" />
        <meta charset="utf-8"/>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <header>
            <?php include("header.php"); ?>
        </header>
        <main>
            <div class="parent">
                <div class="searchbooks">
                    <form action="delete.php" method="POST">
                        <p>
                            Programme
                        </p>
                        <input type="text" name="searchprogramme">
                        <p>
                            Trainer
                        </p>
                        <input type="text" name="searchtrainer" >
                        <input type="submit" value="Search">
                    </form>
                </div>
                <div class="reservebooks">
                    <h3>Programmes</h3>
                    <hr> </hr>
                    <?php

                    $searchprogramme = "";
                    $searchtrainer = "";

                    if (isset($_POST) && !empty($_POST)) {
                    # Get data from form
                        $searchprogramme = trim($_POST['searchprogramme']);
                        $searchtrainer = trim($_POST['searchtrainer']);
                    }

                    $searchprogramme = addslashes($searchprogramme);
                    $searchtrainer = addslashes($searchtrainer);


                    $searchprogramme = htmlentities($searchprogramme);
                    $searchtrainer = htmlentities($searchtrainer);
                   

                    # Open the database
                    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }
                  # Build the query. Users are allowed to search on title, author, or both

                    $query = " SELECT Nr, Program, Trainer FROM Programme";
                    if ($searchprogramme && !$searchtrainer) { // Title search only
                        $query = $query . " where Program like '%" . $searchprogramme . "%'";
                    }
                    if (!$searchprogramme && $searchtrainer) { // Author search only
                        $query = $query . " where Trainer like '%" . $searchtrainer . "%'";
                    }
                    if ($searchprogramme && $searchtrainer) { // Title and Author search
                        $query = $query . " where Program like '%" . $searchprogramme . "%' and Trainer like '%" . $searchtrainer . "%'"; // unfinished
                        
                    }
 
                   
                    # Here's the query using bound result parameters
                        // echo "we are now using bound result parameters <br/>";
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($Nr, $Program, $Trainer); 
                        $stmt->execute();

                        echo '<table cellpadding="6" width="100%">';
                        echo '<tr><b> <td>Nr</td> <td>Programme</td> <td>Trainer</td> <td>Delete</td> </b> </tr>';
                        while ($stmt->fetch()) {
                           

                            echo "<tr>";
                            echo "<td> $Nr </td><td> $Program </td><td> $Trainer </td>";
                            echo '<td><a href="remove.php?Nr=' . urlencode($Nr) . '"> <input type="button" value="delete"> </a></td>';

                            echo "</tr>";
                        }
                        echo "</table>";
                        ?>

                       
                    
                </div>
            </div>
        </main>
        <footer>
                <?php include("footer.php"); ?>
        </footer>
    </body>

</html>